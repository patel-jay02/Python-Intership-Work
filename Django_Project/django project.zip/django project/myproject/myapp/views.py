from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView
from .models import Student

def homepageview(request):
    return render(request,'home.html')

def aboutpageview(request):
    return render(request,'about.html')

def contactpageview(request):
    return render(request,'contact.html')

def myformpageview(request):
    return render(request,'myform.html')

def processpageview(request):
    print("your data succesfully submited")
    print(request.method)
    print(request.POST)
    a = request.POST['Fn']
    b = request.POST['Ln']
    c = request.POST['num']
    d = request.POST['email']
    e = request.POST['about']

    return render(request, 'ans.html',{'mya':a,'myb':b,'myc':c,'myd':d,'mye':e})

def Firstpageview(request):
    print("your data succesfully submited")
    print(request.method)
    print(request.POST)
    f = request.POST['FirstName']
    g = request.POST['LastName']
    h = request.POST['email']
    i = request.POST['Contact']
    j = request.POST['City']
    k = request.POST['Service Type']
    l = request.POST['AdditionalInformation']

    return render(request, 'ans.html',{'myf':f,'myg':g,'myh':h,'myi':i,'myj':j,'myk':k,'myl':l})

    
class studentlist(ListView):
    model = Student
    template_name = 'slist.html'

